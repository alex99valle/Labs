package com.cs3303.shoppingcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity {
    static double price = 0, quantity = 0, taxAmount = 0, totalAmount = 0, tax = 0;
    static int numberOfItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        TextView numberItems;
        EditText nameIn, priceIn, quantityIn;
        numberItems = findViewById(R.id.item);
        nameIn = findViewById(R.id.name);
        priceIn = findViewById(R.id.price);
        quantityIn = findViewById(R.id.quantity);
        Bundle extras = getIntent().getExtras();
        numberOfItems = extras.getInt("ITEMS");
        tax = extras.getDouble("TAX");
        totalAmount = extras.getDouble("TOTAL");

        boolean flag = false;
        if(priceIn.getText().toString().length() == 0) {
            flag = true;
        }
        else {
            price = Double.parseDouble(priceIn.getText().toString());
        }
        if(quantityIn.getText().toString().length() == 0) {
            flag = true;
        }
        else {
            quantity = Double.parseDouble(quantityIn.getText().toString());
        }
        if(!flag) {
            taxAmount = price * quantity * (tax / 100);
            totalAmount = taxAmount + (price * quantity);
            priceIn.setText(String.format("%, .2f", price));
            quantityIn.setText(String.format("%, .0f", quantity));
            numberOfItems++;
        }
        else {
            Toast.makeText(this, "Missing field value", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void finish() {
        Intent i = new Intent();
        i.putExtra("TOTAL", totalAmount);
        i.putExtra("ITEMS", numberOfItems);
        setResult(RESULT_OK, i);
        super.finish();
    }
}
